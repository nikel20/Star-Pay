import { create } from 'zustand';

export interface User {
  id: string;
  name: string;
  coins: number;
  balanceUSDT: number;
  xpLevel: number;
  farmingMultiplier: number;
  referralMultiplier: number;
  adsLimitPerDay: number | 'Unlimited';
  adsWatchedToday: number;
  vipTier: 'Free' | 'VIP 1' | 'VIP 2';
  boostEndTime: number | null;
  streak: number;
  lastClaimDate: string | null;
  referralCount: number;
  earningsFromRef: number;
  referrerId: string | null;
}

export interface Task {
  id: string;
  title: string;
  reward: number;
  link: string;
}

export interface Withdrawal {
  id: string;
  userId: string;
  amount: number;
  method: 'Binance UID' | 'bKash' | 'Nagad';
  accountDetails: string;
  status: 'pending' | 'paid' | 'rejected';
  timestamp: number;
}

export interface AdminSettings {
  inrExchangeRate: number; // Coins to $0.01
  baseAdReward: number;
  vipPrices: {
    'VIP 1': number;
    'VIP 2': number;
  };
  vipMultipliers: {
    'Free': { farming: 1.0, referral: 1.0 };
    'VIP 1': { farming: 2.0, referral: 1.5 };
    'VIP 2': { farming: 2.5, referral: 2.0 };
  };
  withdrawalLimits: {
    'Free': { min: 1.5, dailyCount: 1 };
    'VIP 1': { min: 2.0, dailyCount: 3 };
    'VIP 2': { min: 4.0, dailyCount: 5 };
  };
}

interface AppStore {
  currentUser: User | null;
  tasks: Task[];
  withdrawals: Withdrawal[];
  adminSettings: AdminSettings;
  setCurrentUser: (user: User) => void;
  updateUser: (updates: Partial<User>) => void;
  activateSubscription: (userId: string, tier: 'VIP 1' | 'VIP 2', durationDays: number, price: number) => boolean;
  claimDaily: () => void;
  watchAd: () => boolean;
  requestWithdrawal: (amount: number, method: Withdrawal['method'], accountDetails: string) => boolean;
  updateAdminSettings: (updates: Partial<AdminSettings>) => void;
  approveWithdrawal: (id: string) => void;
  rejectWithdrawal: (id: string) => void;
  initializeUser: (startParam: string | null) => void;
}

// Initial mock data
const initialAdminSettings: AdminSettings = {
  inrExchangeRate: 1000, 
  baseAdReward: 50,
  vipPrices: {
    'VIP 1': 75,
    'VIP 2': 150,
  },
  vipMultipliers: {
    'Free': { farming: 1.0, referral: 1.0 },
    'VIP 1': { farming: 2.0, referral: 1.5 },
    'VIP 2': { farming: 2.5, referral: 2.0 },
  },
  withdrawalLimits: {
    'Free': { min: 1.5, dailyCount: 1 },
    'VIP 1': { min: 2.0, dailyCount: 3 },
    'VIP 2': { min: 4.0, dailyCount: 5 },
  }
};

const defaultUser: User = {
  id: 'user123',
  name: 'Telegram User',
  coins: 500,
  balanceUSDT: 0.5,
  xpLevel: 1,
  farmingMultiplier: 1.0,
  referralMultiplier: 1.0,
  adsLimitPerDay: 5,
  adsWatchedToday: 0,
  vipTier: 'Free',
  boostEndTime: null,
  streak: 0,
  lastClaimDate: null,
  referralCount: 0,
  earningsFromRef: 0,
  referrerId: null,
};

export const useAppStore = create<AppStore>((set, get) => ({
  currentUser: null,
  tasks: [
    { id: 't1', title: 'Join our Official Channel', reward: 200, link: 'https://t.me/example' },
    { id: 't2', title: 'Follow on Twitter', reward: 150, link: 'https://twitter.com' },
  ],
  withdrawals: [
    { id: 'w1', userId: 'user123', amount: 2, method: 'Binance UID', accountDetails: 'uid123456', status: 'pending', timestamp: Date.now() - 3600000 }
  ],
  adminSettings: initialAdminSettings,

  setCurrentUser: (user) => set({ currentUser: user }),
  updateUser: (updates) => set((state) => ({ 
    currentUser: state.currentUser ? { ...state.currentUser, ...updates } : null 
  })),

  initializeUser: (startParam) => {
    // In a real app, logic to fetch or create user with startParam (referrer ID)
    const { currentUser } = get();
    if (!currentUser) {
      const newUser = { ...defaultUser, referrerId: startParam };
      set({ currentUser: newUser });
    }
  },

  activateSubscription: (userId, tier, durationDays, price) => {
    const { currentUser, adminSettings } = get();
    if (!currentUser) return false;
    // Assuming Stars payment happens before this, we just deduct stars or mock it
    // Using coins as mock currency for Stars payment in this sandbox if needed, 
    // but typically Telegram handles Stars natively via Invoice, calling webhook on success.
    
    const multipliers = adminSettings.vipMultipliers[tier];
    const limits = adminSettings.withdrawalLimits[tier];
    
    set((state) => {
      if (!state.currentUser) return state;
      return {
        currentUser: {
          ...state.currentUser,
          vipTier: tier,
          farmingMultiplier: multipliers.farming,
          referralMultiplier: multipliers.referral,
          adsLimitPerDay: 'Unlimited',
          boostEndTime: Date.now() + durationDays * 24 * 60 * 60 * 1000,
        }
      };
    });
    return true; // Subscription activated
  },

  claimDaily: () => {
    const { currentUser } = get();
    if (!currentUser) return;
    
    // Streak logic (basic implementation)
    const today = new Date().toISOString().split('T')[0];
    if (currentUser.lastClaimDate === today) return; // Already claimed

    let newStreak = currentUser.streak + 1;
    // Simple reset if missed a day logic could be added here
    const reward = 100 * newStreak * currentUser.farmingMultiplier;

    set((state) => {
      if (!state.currentUser) return state;
      return {
        currentUser: {
          ...state.currentUser,
          streak: newStreak > 7 ? 1 : newStreak,
          lastClaimDate: today,
          coins: state.currentUser.coins + reward,
        }
      };
    });
  },

  watchAd: () => {
    const { currentUser, adminSettings } = get();
    if (!currentUser) return false;

    if (currentUser.adsLimitPerDay !== 'Unlimited' && currentUser.adsWatchedToday >= currentUser.adsLimitPerDay) {
      return false; // Limit reached
    }

    const reward = adminSettings.baseAdReward * currentUser.farmingMultiplier;

    set((state) => {
      if (!state.currentUser) return state;
      return {
        currentUser: {
          ...state.currentUser,
          adsWatchedToday: state.currentUser.adsWatchedToday + 1,
          coins: state.currentUser.coins + reward,
        }
      };
    });
    return true;
  },

  requestWithdrawal: (amount, method, accountDetails) => {
    const { currentUser, adminSettings } = get();
    if (!currentUser) return false;

    const limits = adminSettings.withdrawalLimits[currentUser.vipTier];
    if (amount < limits.min) return false;
    if (amount > currentUser.balanceUSDT) return false;

    // Check daily limit (in a real app, count withdrawals today)
    // Decrement balance
    set((state) => {
      if (!state.currentUser) return state;
      return {
        currentUser: {
          ...state.currentUser,
          balanceUSDT: state.currentUser.balanceUSDT - amount,
        },
        withdrawals: [
          ...state.withdrawals,
          {
            id: 'wd_' + Date.now(),
            userId: state.currentUser.id,
            amount,
            method,
            accountDetails,
            status: 'pending',
            timestamp: Date.now()
          }
        ]
      };
    });
    return true;
  },

  updateAdminSettings: (updates) => set((state) => ({ adminSettings: { ...state.adminSettings, ...updates } })),
  
  approveWithdrawal: (id) => set((state) => ({
    withdrawals: state.withdrawals.map(w => w.id === id ? { ...w, status: 'paid' } : w)
  })),

  rejectWithdrawal: (id) => set((state) => {
    // In a real app we might refund the balance
    return {
      withdrawals: state.withdrawals.map(w => w.id === id ? { ...w, status: 'rejected' } : w)
    };
  })
}));
