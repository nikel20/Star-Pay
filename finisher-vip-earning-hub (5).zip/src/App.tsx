/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect, useState } from 'react';
import UserApp from './UserApp';
import AdminApp from './AdminApp';
import { useAppStore } from './store/useAppStore';
import { Toaster } from 'react-hot-toast';

export default function App() {
  const [isAdminRoute, setIsAdminRoute] = useState(false);
  const initializeUser = useAppStore(state => state.initializeUser);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    
    // Check if it's the admin route
    if (params.get('admin') === 'true' && params.get('key') === 'SECRET_KEY') {
      setIsAdminRoute(true);
    } else {
      // Logic for user route: capture Referral logic (start_parameter from Telegram Web App)
      // Usually provided via window.Telegram.WebApp.initDataUnsafe.start_param
      // We will fallback to URL params for demo purposes.
      const startParam = params.get('start') || null;
      initializeUser(startParam);
    }
  }, [initializeUser]);

  return (
    <div className="min-h-screen bg-gray-950 text-white font-sans max-w-lg mx-auto relative shadow-2xl overflow-hidden">
      {isAdminRoute ? <AdminApp /> : <UserApp />}
      <Toaster position="top-center" theme="dark" />
    </div>
  );
}
