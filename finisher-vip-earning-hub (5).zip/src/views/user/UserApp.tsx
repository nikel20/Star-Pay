import { useState } from 'react';
import { Home, ListTodo, Users, ShoppingBag, User } from 'lucide-react';
import DashboardView from './views/user/DashboardView';
import TaskView from './views/user/TaskView';
import ReferralView from './views/user/ReferralView';
import ShopWithdrawalView from './views/user/ShopWithdrawalView';
import ProfileView from './views/user/ProfileView';
import { cn } from './lib/utils';
import { useAppStore } from './store/useAppStore';

type Tab = 'home' | 'task' | 'ref' | 'shop' | 'profile';

export default function UserApp() {
  const [activeTab, setActiveTab] = useState<Tab>('home');
  const currentUser = useAppStore(state => state.currentUser);

  if (!currentUser) {
    return <div className="flex items-center justify-center h-screen">Loading Web App...</div>;
  }

  return (
    <div className="flex flex-col h-[100dvh]">
      <div className="flex-1 overflow-y-auto pb-24">
        {activeTab === 'home' && <DashboardView />}
        {activeTab === 'task' && <TaskView />}
        {activeTab === 'ref' && <ReferralView />}
        {activeTab === 'shop' && <ShopWithdrawalView />}
        {activeTab === 'profile' && <ProfileView />}
      </div>

      <nav className="fixed bottom-0 w-full max-w-lg bg-gray-900 border-t border-gray-800 flex justify-between px-2 py-3 pb-safe z-50 shrink-0">
        <NavItem icon={<Home size={22} />} label="Home" active={activeTab === 'home'} onClick={() => setActiveTab('home')} />
        <NavItem icon={<ListTodo size={22} />} label="Tasks" active={activeTab === 'task'} onClick={() => setActiveTab('task')} />
        <NavItem icon={<Users size={22} />} label="Frens" active={activeTab === 'ref'} onClick={() => setActiveTab('ref')} />
        <NavItem icon={<ShoppingBag size={22} />} label="Shop" active={activeTab === 'shop'} onClick={() => setActiveTab('shop')} />
        <NavItem icon={<User size={22} />} label="Profile" active={activeTab === 'profile'} onClick={() => setActiveTab('profile')} />
      </nav>
    </div>
  );
}

function NavItem({ icon, label, active, onClick }: { icon: React.ReactNode, label: string, active: boolean, onClick: () => void }) {
  return (
    <button 
      onClick={onClick}
      className={cn(
        "flex flex-col items-center w-16 transition-all duration-300",
        active ? "text-amber-400 scale-110" : "text-gray-500 hover:text-gray-300"
      )}
    >
      <div className={cn("p-1.5 rounded-full mb-1", active && "bg-amber-400/20")}>
        {icon}
      </div>
      <span className="text-[10px] font-medium tracking-wide">{label}</span>
    </button>
  );
}
