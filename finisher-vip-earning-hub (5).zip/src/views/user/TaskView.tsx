import { useState, useEffect } from 'react';
import { useAppStore } from '../../store/useAppStore';
import { Play, CheckCircle, ExternalLink } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import toast from 'react-hot-toast';
import { cn } from '../../lib/utils';

export default function TaskView() {
  const { tasks, currentUser, watchAd } = useAppStore();
  const [activeTaskTimer, setActiveTaskTimer] = useState<number | null>(null);
  const [currentTask, setCurrentTask] = useState<string | null>(null);
  const [completedDemoTasks, setCompletedDemoTasks] = useState<string[]>([]);
  
  if (!currentUser) return null;

  useEffect(() => {
    let interval: any;
    if (activeTaskTimer !== null && activeTaskTimer > 0) {
      interval = setInterval(() => {
        setActiveTaskTimer((prev) => (prev ? prev - 1 : 0));
      }, 1000);
    } else if (activeTaskTimer === 0 && currentTask) {
      // Ready to claim
      clearInterval(interval);
    }
    return () => clearInterval(interval);
  }, [activeTaskTimer, currentTask]);

  const handleStartTask = (taskId: string, link: string) => {
    // Open link in standard app
    window.open(link, '_blank');
    setCurrentTask(taskId);
    setActiveTaskTimer(10); // 10 seconds timer
  };

  const handleClaimTask = (taskId: string) => {
    setCurrentTask(null);
    setActiveTaskTimer(null);
    setCompletedDemoTasks([...completedDemoTasks, taskId]);
    
    // Animate coins & update state
    toast.success('Task claimed! +Coins');
  };

  const handleWatchAd = () => {
    const success = watchAd();
    if (success) {
      toast.success('Ad reward claimed!');
    } else {
      toast.error('Daily ad limit reached Upgrade to VIP.');
    }
  };

  return (
    <div className="p-4 space-y-6">
      <div className="text-center pt-4">
        <h2 className="text-3xl font-black mb-2">Earn Coins</h2>
        <p className="text-gray-400 font-medium">Complete tasks to increase balance</p>
      </div>

      {/* Ads Tag */}
      <div className="bg-gradient-to-r from-blue-600/20 to-indigo-600/20 border border-blue-500/30 rounded-2xl p-5 relative overflow-hidden">
        <div className="flex justify-between items-center relative z-10">
          <div>
            <h3 className="font-bold text-blue-400 text-lg mb-1">Watch Ads</h3>
            <p className="text-xs text-gray-400">
              {currentUser.adsLimitPerDay === 'Unlimited' 
                ? 'Unlimited Ads (VIP)' 
                : `${currentUser.adsWatchedToday} / ${currentUser.adsLimitPerDay} daily limit`}
            </p>
          </div>
          <button 
            onClick={handleWatchAd}
            className="flex items-center gap-2 bg-blue-600 hover:bg-blue-500 px-4 py-2 rounded-xl font-bold transition-all"
          >
            <Play size={16} fill="currentColor" /> Watch
          </button>
        </div>
      </div>

      {/* Tasks List */}
      <div className="space-y-3">
        <h3 className="font-bold text-gray-400 uppercase text-xs tracking-widest pl-2">Social Tasks</h3>
        {tasks.map(task => {
          const isCompleted = completedDemoTasks.includes(task.id);
          const isActive = currentTask === task.id;

          return (
            <div key={task.id} className="bg-gray-800 rounded-2xl p-4 flex items-center justify-between border border-gray-700 shadow-sm">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-gray-900 rounded-xl flex items-center justify-center shrink-0">
                  <ExternalLink className="text-gray-400" size={20} />
                </div>
                <div>
                  <h4 className="font-bold text-sm text-gray-200">{task.title}</h4>
                  <p className="text-amber-400 text-xs font-bold mt-1">+{task.reward} Coins</p>
                </div>
              </div>

              {isCompleted ? (
                <div className="text-emerald-500 pr-2">
                  <CheckCircle size={24} />
                </div>
              ) : isActive ? (
                <button 
                  onClick={() => activeTaskTimer === 0 && handleClaimTask(task.id)}
                  disabled={activeTaskTimer! > 0}
                  className={cn(
                    "px-4 py-2 rounded-xl text-sm font-bold min-w-24 transition-colors",
                    activeTaskTimer === 0 
                      ? "bg-amber-500 text-gray-900 hover:bg-amber-400" 
                      : "bg-gray-700 text-gray-400 cursor-wait"
                  )}
                >
                  {activeTaskTimer! > 0 ? `${activeTaskTimer}s` : 'Claim'}
                </button>
              ) : (
                <button 
                  onClick={() => handleStartTask(task.id, task.link)}
                  className="px-4 py-2 bg-white text-black hover:bg-gray-200 rounded-xl text-sm font-bold transition-colors"
                >
                  Start
                </button>
              )}
            </div>
          )
        })}
      </div>
    </div>
  );
}
