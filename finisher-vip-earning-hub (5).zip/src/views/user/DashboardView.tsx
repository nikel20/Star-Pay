import { useAppStore } from '../../store/useAppStore';
import { Zap, Coins, CalendarDays, Rocket } from 'lucide-react';
import { motion } from 'motion/react';
import { cn } from '../../lib/utils';
import toast from 'react-hot-toast';

export default function DashboardView() {
  const { currentUser, claimDaily } = useAppStore();
  if (!currentUser) return null;

  const handleClaim = () => {
    claimDaily();
    toast.success('Daily reward claimed!');
  };

  const today = new Date().toISOString().split('T')[0];
  const canClaim = currentUser.lastClaimDate !== today;

  return (
    <div className="p-4 space-y-6">
      {/* Top Section */}
      <div className="bg-gradient-to-br from-amber-500/10 to-orange-500/10 border border-amber-500/20 rounded-3xl p-6 relative overflow-hidden">
        <div className="relative z-10 text-center">
          <p className="text-amber-500 text-sm font-bold uppercase tracking-widest mb-2">Total Balance</p>
          <div className="flex items-center justify-center gap-2 mb-1">
            <Coins size={32} className="text-amber-400" />
            <h1 className="text-5xl font-black text-white">{currentUser.coins.toLocaleString()}</h1>
          </div>
          <p className="text-gray-400 font-medium">≈ ${currentUser.balanceUSDT.toFixed(2)} USDT</p>
        </div>
        <div className="absolute -top-10 -right-10 opacity-10">
          <Coins size={150} />
        </div>
      </div>

      {/* Progress & Stats */}
      <div className="bg-gray-800 rounded-2xl p-5 border border-gray-700">
        <div className="flex justify-between items-end mb-2">
          <div>
            <p className="text-xs text-gray-400 font-medium uppercase">Farming Progress</p>
            <p className="font-bold text-lg">Level {currentUser.xpLevel}</p>
          </div>
          <span className="text-sm text-gray-500 font-mono">45%</span>
        </div>
        <div className="w-full bg-gray-900 rounded-full h-3 mb-4 overflow-hidden">
          <div className="bg-gradient-to-r from-blue-500 to-indigo-500 h-3 rounded-full" style={{ width: '45%' }}></div>
        </div>

        <div className="flex divide-x divide-gray-700">
          <div className="flex-1 text-center">
            <p className="text-gray-400 text-xs mb-1">Farming</p>
            <p className="font-bold text-blue-400">{currentUser.farmingMultiplier}x</p>
          </div>
          <div className="flex-1 text-center">
            <p className="text-gray-400 text-xs mb-1">Referral</p>
            <p className="font-bold text-emerald-400">{currentUser.referralMultiplier}x</p>
          </div>
        </div>
      </div>

      {/* Daily Claim */}
      <div className="bg-gray-800 rounded-2xl p-5 border border-gray-700">
        <div className="flex justify-between items-center mb-4">
          <div className="flex items-center gap-2">
            <CalendarDays className="text-purple-400" />
            <h3 className="font-bold">Daily Calendar</h3>
          </div>
          <span className="bg-gray-900 px-3 py-1 rounded-full text-xs font-bold text-purple-400">
            {currentUser.streak} Day Streak
          </span>
        </div>

        <button 
          onClick={handleClaim}
          disabled={!canClaim}
          className={cn(
            "w-full py-4 rounded-xl font-bold transition-all disabled:opacity-50 disabled:cursor-not-allowed",
            canClaim 
              ? "bg-gradient-to-r from-purple-600 to-indigo-600 hover:opacity-90 shadow-[0_0_20px_rgba(168,85,247,0.4)]" 
              : "bg-gray-700 text-gray-400"
          )}
        >
          {canClaim ? 'Claim Daily Reward' : 'Come back tomorrow'}
        </button>
      </div>

      {/* Booster Status */}
      <div className="bg-gradient-to-r from-gray-800 to-gray-900 rounded-2xl p-5 border border-gray-700 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className={cn(
            "p-3 rounded-xl",
            currentUser.vipTier === 'Free' ? "bg-gray-700" : "bg-gradient-to-br from-amber-400 to-orange-500"
          )}>
            <Rocket size={24} className={currentUser.vipTier === 'Free' ? "text-gray-400" : "text-white"} />
          </div>
          <div>
            <h3 className="font-bold">Booster Status</h3>
            <p className={cn(
              "text-sm font-medium",
              currentUser.vipTier === 'Free' ? "text-gray-500" : "text-amber-400"
            )}>
              {currentUser.vipTier === 'Free' ? 'Inactive' : `${currentUser.vipTier} Active`}
            </p>
          </div>
        </div>
        <div className="text-right">
          <p className="font-bold text-xl">{currentUser.farmingMultiplier}x</p>
          <p className="text-[10px] text-gray-500 uppercase tracking-wide">Speed</p>
        </div>
      </div>
    </div>
  );
}
