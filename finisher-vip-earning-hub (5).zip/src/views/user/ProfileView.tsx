import { useAppStore } from '../../store/useAppStore';
import { UserCircle2, CheckCircle2, ShieldAlert } from 'lucide-react';
import { cn } from '../../lib/utils';
import { motion } from 'motion/react';

export default function ProfileView() {
  const { currentUser } = useAppStore();
  if (!currentUser) return null;

  return (
    <div className="p-4 space-y-4 pt-10">
      
      <div className="bg-gray-800 border border-gray-700 rounded-3xl p-6 text-center shadow-xl relative overflow-hidden">
        {/* Dynamic Background aura based on VIP */}
        <div className={cn(
          "absolute inset-0 opacity-10 blur-3xl",
          currentUser.vipTier === 'Free' ? "bg-blue-500" : currentUser.vipTier === 'VIP 1' ? "bg-purple-500" : "bg-amber-500"
        )}></div>

        <div className="relative z-10 flex flex-col items-center">
          <div className="mb-4 relative">
            <UserCircle2 size={80} className="text-gray-400" />
            <motion.div 
               initial={{ scale: 0 }}
               animate={{ scale: 1 }}
               className="absolute -bottom-2 -right-2"
            >
               {currentUser.vipTier !== 'Free' ? (
                 <CheckCircle2 size={28} className={cn("fill-gray-900", currentUser.vipTier === 'VIP 1' ? "text-purple-400" : "text-amber-400")} />
               ) : (
                 <ShieldAlert size={28} className="text-gray-500 fill-gray-900" />
               )}
            </motion.div>
          </div>
          
          <h2 className="text-2xl font-black text-white">{currentUser.name}</h2>
          <p className="text-gray-400 font-mono text-sm mt-1">ID: {currentUser.id}</p>

          <div className="mt-6 inline-flex bg-gray-900 p-1 rounded-xl border border-gray-800 shadow-inner">
             <div className={cn(
               "px-6 py-2 rounded-lg text-sm font-black tracking-widest uppercase",
               currentUser.vipTier === 'Free' ? "text-gray-400" :
               currentUser.vipTier === 'VIP 1' ? "bg-purple-500/20 text-purple-400" : "bg-amber-500/20 text-amber-400 shadow-[0_0_15px_rgba(245,158,11,0.3)]"
             )}>
                {currentUser.vipTier} Member
             </div>
          </div>
        </div>
      </div>

      <div className="bg-gray-800 rounded-2xl p-4 border border-gray-700 space-y-4">
         <h3 className="text-sm font-bold text-gray-500 uppercase tracking-widest mb-2 px-2">Account Details</h3>
         
         <div className="flex justify-between items-center py-2 px-2 border-b border-gray-700/50">
            <span className="text-gray-400 font-medium">Joined</span>
            <span className="text-white font-mono text-sm">Oct 2023</span>
         </div>
         <div className="flex justify-between items-center py-2 px-2 border-b border-gray-700/50">
            <span className="text-gray-400 font-medium">Wallet Address</span>
            <span className="text-white font-mono text-sm">Not Linked</span>
         </div>
         <div className="flex justify-between items-center py-2 px-2">
            <span className="text-gray-400 font-medium">Platform</span>
            <span className="text-white font-mono text-sm">Telegram Web App</span>
         </div>
      </div>

      {currentUser.vipTier === 'Free' && (
         <div className="mt-6 text-center">
            <p className="text-xs text-gray-500 px-8">Upgrade to VIP in the Shop to unlock unlimited daily ads and higher withdrawal limits.</p>
         </div>
      )}
    </div>
  );
}
