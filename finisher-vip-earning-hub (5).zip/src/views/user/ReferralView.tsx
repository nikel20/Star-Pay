import { useAppStore } from '../../store/useAppStore';
import { Copy, Users, TrendingUp } from 'lucide-react';
import toast from 'react-hot-toast';

export default function ReferralView() {
  const { currentUser, adminSettings } = useAppStore();
  if (!currentUser) return null;

  const botLink = `http://t.me/Finisher_task_bot?start=${currentUser.id}`;

  const copyLink = () => {
    navigator.clipboard.writeText(botLink);
    toast.success('Referral link copied!');
  };

  return (
    <div className="p-4 space-y-6">
      <div className="text-center pt-8 pb-4">
        <div className="w-20 h-20 bg-emerald-500/10 rounded-full flex items-center justify-center mx-auto mb-4 border border-emerald-500/20">
          <Users size={32} className="text-emerald-400" />
        </div>
        <h2 className="text-3xl font-black mb-2">Invite Frens</h2>
        <p className="text-gray-400 font-medium">Earn more with an active network</p>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="bg-gray-800 border border-gray-700 p-5 rounded-2xl text-center">
          <p className="text-gray-400 text-xs uppercase tracking-wider mb-2 font-medium">Total Frens</p>
          <p className="text-3xl font-black text-white">{currentUser.referralCount}</p>
        </div>
        <div className="bg-gray-800 border border-gray-700 p-5 rounded-2xl text-center">
          <p className="text-gray-400 text-xs uppercase tracking-wider mb-2 font-medium">Earned Coins</p>
          <div className="flex justify-center items-center gap-1">
             <TrendingUp size={16} className="text-emerald-400" />
             <p className="text-3xl font-black text-white">{currentUser.earningsFromRef}</p>
          </div>
        </div>
      </div>

      <div className="bg-gray-800 border border-gray-700 p-5 rounded-2xl space-y-4">
        <div className="flex justify-between items-center">
          <h3 className="font-bold text-gray-200">Your Invite Link</h3>
          <span className="text-xs bg-emerald-500/20 text-emerald-400 px-2 py-1 rounded-lg font-bold">
            {currentUser.referralMultiplier}x Boost
          </span>
        </div>
        
        <div className="flex items-center gap-2 bg-gray-900 border border-gray-700 rounded-xl p-2 pl-4">
          <p className="flex-1 text-sm text-gray-400 truncate select-all">{botLink}</p>
          <button 
            onClick={copyLink}
            className="p-3 bg-white hover:bg-gray-200 text-black rounded-lg transition-colors"
          >
            <Copy size={16} />
          </button>
        </div>
      </div>
      
      <div className="px-2">
         <p className="text-xs text-gray-500 text-center uppercase tracking-widest font-bold">How it works</p>
         <ul className="text-sm text-gray-400 mt-4 space-y-3 list-disc pl-5">
            <li>Share your unique link with friends.</li>
            <li>When they authorize the Web App, they become your referral.</li>
            <li>Earn base rewards + multiplier percentage on their activity!</li>
         </ul>
      </div>
    </div>
  );
}
