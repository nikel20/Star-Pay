import { useState } from 'react';
import { useAppStore } from '../../store/useAppStore';
import toast from 'react-hot-toast';

export default function AdminSettingsView() {
  const { adminSettings, updateAdminSettings } = useAppStore();
  
  const [exchangeRate, setExchangeRate] = useState(adminSettings.inrExchangeRate.toString());
  const [baseReward, setBaseReward] = useState(adminSettings.baseAdReward.toString());

  const handleSave = () => {
    updateAdminSettings({
      inrExchangeRate: Number(exchangeRate),
      baseAdReward: Number(baseReward)
    });
    toast.success('Settings updated successfully!');
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">Business Control</h2>
      
      <div className="bg-gray-800 rounded-2xl p-4 space-y-4 border border-gray-700">
        <div>
          <label className="block text-sm font-medium text-gray-400 mb-1">Exchange Rate (Coins per $0.01)</label>
          <input 
            type="number" 
            value={exchangeRate}
            onChange={(e) => setExchangeRate(e.target.value)}
            className="w-full bg-gray-900 border border-gray-700 rounded-xl p-3 text-white focus:outline-none focus:border-red-500"
          />
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-400 mb-1">Base Ad Reward (Coins)</label>
          <input 
            type="number" 
            value={baseReward}
            onChange={(e) => setBaseReward(e.target.value)}
            className="w-full bg-gray-900 border border-gray-700 rounded-xl p-3 text-white focus:outline-none focus:border-red-500"
          />
        </div>

        <button 
          onClick={handleSave}
          className="w-full py-3 bg-red-600 hover:bg-red-700 rounded-xl font-bold transition-colors"
        >
          Save Configuration
        </button>
      </div>

      <div className="bg-gray-800 rounded-2xl p-4 border border-gray-700 opacity-60">
        <p className="text-xs text-gray-400 text-center uppercase tracking-wide font-bold">VIP Settings (View Only in Demo)</p>
        <div className="mt-4 space-y-2 text-sm text-gray-300">
          <div className="flex justify-between">
            <span>VIP 1 Price:</span> <span>{adminSettings.vipPrices['VIP 1']} Stars</span>
          </div>
          <div className="flex justify-between">
            <span>VIP 2 Price:</span> <span>{adminSettings.vipPrices['VIP 2']} Stars</span>
          </div>
        </div>
      </div>
    </div>
  );
}
