import { useAppStore } from '../../store/useAppStore';
import { format } from 'date-fns';
import toast from 'react-hot-toast';

export default function AdminApprovals() {
  const { withdrawals, approveWithdrawal, rejectWithdrawal } = useAppStore();

  const pendingWd = withdrawals.filter(w => w.status === 'pending');

  const handleApprove = (id: string) => {
    approveWithdrawal(id);
    toast.success('Withdrawal marked as Paid');
  };

  const handleReject = (id: string) => {
    rejectWithdrawal(id);
    toast.error('Withdrawal rejected');
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">W/D Requests</h2>
      
      {pendingWd.length === 0 ? (
        <div className="bg-gray-800 border border-gray-700 p-8 rounded-xl text-center text-gray-500">
          No pending requests
        </div>
      ) : (
        <div className="space-y-4">
          {pendingWd.map(wd => (
            <div key={wd.id} className="bg-gray-800 border border-gray-700 p-4 rounded-2xl shadow-sm">
              <div className="flex justify-between items-start mb-3">
                <div>
                  <span className="text-xs text-gray-400 block mb-1">
                    {format(new Date(wd.timestamp), 'MMM d, HH:mm')}
                  </span>
                  <div className="font-bold text-lg">${wd.amount}</div>
                </div>
                <div className="bg-gray-900 px-3 py-1 rounded-full text-xs font-semibold text-blue-400">
                  {wd.method}
                </div>
              </div>
              
              <div className="bg-gray-900 p-3 rounded-xl text-sm mb-4 break-all text-gray-300 font-mono">
                {wd.accountDetails}
              </div>

              <div className="flex gap-2">
                <button 
                  onClick={() => handleApprove(wd.id)}
                  className="flex-1 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold text-sm transition-colors"
                >
                  Approve (Pay)
                </button>
                <button 
                  onClick={() => handleReject(wd.id)}
                  className="flex-1 py-2 bg-gray-700 hover:bg-gray-600 text-white rounded-lg font-bold text-sm transition-colors"
                >
                  Reject
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
