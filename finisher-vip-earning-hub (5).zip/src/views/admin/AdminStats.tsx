import { useAppStore } from '../../store/useAppStore';
import { Users, DollarSign, Wallet, Gem } from 'lucide-react';
import { motion } from 'motion/react';

export default function AdminStats() {
  const { adminSettings, withdrawals } = useAppStore();
  
  // Mock aggregated data for demo
  const totalUsers = 1245;
  const activeVIPs = 345;
  const totalCoins = 450000;
  
  // Calculate total USDT from paid withdrawals and VIP purchases
  const totalUSDTGenerated = 5600; 

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">Analytics Overview</h2>
      
      <div className="grid grid-cols-2 gap-4">
        <StatCard 
          title="Total Users" 
          value={totalUsers.toLocaleString()} 
          icon={<Users size={20} className="text-blue-400" />} 
          delay={0.1}
        />
        <StatCard 
          title="Active VIPs" 
          value={activeVIPs.toLocaleString()} 
          icon={<Gem size={20} className="text-amber-400" />} 
          delay={0.2}
        />
        <StatCard 
          title="Coin Dist." 
          value={totalCoins.toLocaleString()} 
          icon={<DollarSign size={20} className="text-emerald-400" />} 
          delay={0.3}
        />
        <StatCard 
          title="USDT Gen." 
          value={`$${totalUSDTGenerated.toLocaleString()}`} 
          icon={<Wallet size={20} className="text-purple-400" />} 
          delay={0.4}
        />
      </div>
    </div>
  );
}

function StatCard({ title, value, icon, delay }: { title: string, value: string | number, icon: React.ReactNode, delay: number }) {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay }}
      className="bg-gray-800 p-4 rounded-2xl border border-gray-700 shadow-lg"
    >
      <div className="flex justify-between items-start mb-2">
        <div className="p-2 bg-gray-900 rounded-lg">{icon}</div>
      </div>
      <p className="text-gray-400 text-xs font-medium">{title}</p>
      <p className="text-xl font-bold mt-1">{value}</p>
    </motion.div>
  );
}
