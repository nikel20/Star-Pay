import { useState } from 'react';
import { useAppStore } from '../../store/useAppStore';
import { Star, ShieldCheck, Wallet, ArrowRight } from 'lucide-react';
import { cn } from '../../lib/utils';
import toast from 'react-hot-toast';

export default function ShopWithdrawalView() {
  const { currentUser, adminSettings, requestWithdrawal, activateSubscription } = useAppStore();
  const [tab, setTab] = useState<'shop' | 'withdraw'>('shop');

  const [wdAmount, setWdAmount] = useState('');
  const [wdMethod, setWdMethod] = useState<'Binance UID' | 'bKash' | 'Nagad'>('Binance UID');
  const [wdDetails, setWdDetails] = useState('');

  if (!currentUser) return null;

  const handleBuyVIP = (tier: 'VIP 1' | 'VIP 2', price: number) => {
    // In actual Tg mini app, trigger Telegram.WebApp.openInvoice...
    // Here we just mock the success immediately
    if (activateSubscription(currentUser.id, tier, 30, price)) {
      toast.success(`${tier} activated successfully!`);
    }
  };

  const currentLimits = adminSettings.withdrawalLimits[currentUser.vipTier];

  const handleWithdraw = () => {
    const amount = Number(wdAmount);
    if (!amount || amount < currentLimits.min) {
      toast.error(`Minimum withdrawal is $${currentLimits.min}`);
      return;
    }
    if (!wdDetails) {
      toast.error('Please enter account details');
      return;
    }

    const success = requestWithdrawal(amount, wdMethod, wdDetails);
    if (success) {
      toast.success('Withdrawal requested successfully');
      setWdAmount('');
      setWdDetails('');
    } else {
      toast.error('Insufficient funds or daily limit reached');
    }
  };

  return (
    <div className="p-4 space-y-6">
      {/* Tabs */}
      <div className="bg-gray-900 border border-gray-800 p-1.5 rounded-2xl flex gap-1">
        <button 
          onClick={() => setTab('shop')}
          className={cn("flex-1 py-3 rounded-xl text-sm font-bold transition-all", tab === 'shop' ? "bg-gray-800 text-white shadow" : "text-gray-500 hover:text-white")}
        >
          Boosters Shop
        </button>
        <button 
          onClick={() => setTab('withdraw')}
          className={cn("flex-1 py-3 rounded-xl text-sm font-bold transition-all", tab === 'withdraw' ? "bg-gray-800 text-white shadow" : "text-gray-500 hover:text-white")}
        >
          Withdrawal
        </button>
      </div>

      {tab === 'shop' && (
        <div className="space-y-4">
          <VIPCard 
            tier="VIP 1" 
            price={adminSettings.vipPrices['VIP 1']} 
            features={['2.0x Farming Speed', '1.5x Referral Bonus', 'Unlimited Ads', 'Min W/D: $2.0']} 
            onBuy={() => handleBuyVIP('VIP 1', adminSettings.vipPrices['VIP 1'])}
            active={currentUser.vipTier === 'VIP 1'}
          />
          <VIPCard 
            tier="VIP 2" 
            price={adminSettings.vipPrices['VIP 2']} 
            features={['2.5x Farming Speed', '2.0x Referral Bonus', 'Unlimited Ads', 'Min W/D: $4.0']} 
            isPremium
            onBuy={() => handleBuyVIP('VIP 2', adminSettings.vipPrices['VIP 2'])}
            active={currentUser.vipTier === 'VIP 2'}
          />
        </div>
      )}

      {tab === 'withdraw' && (
        <div className="bg-gray-800 border border-gray-700 rounded-3xl p-6">
          <div className="mb-6 flex items-center justify-between">
            <h3 className="text-xl font-bold flex items-center gap-2"><Wallet className="text-blue-400"/> Cash Out</h3>
            <span className="bg-blue-500/10 text-blue-400 font-mono text-sm px-3 py-1 rounded-full border border-blue-500/20">
              Bal: ${currentUser.balanceUSDT.toFixed(2)}
            </span>
          </div>

          <div className="space-y-5">
            <div>
              <label className="block text-xs uppercase tracking-wider text-gray-500 mb-2 font-bold">Payout Method</label>
              <div className="grid grid-cols-3 gap-2">
                {['Binance UID', 'bKash', 'Nagad'].map((m) => (
                  <button 
                    key={m}
                    onClick={() => setWdMethod(m as any)}
                    className={cn(
                      "py-3 text-xs font-bold rounded-xl border transition-all",
                      wdMethod === m ? "bg-blue-600 text-white border-blue-500" : "bg-gray-900 border-gray-700 text-gray-400 hover:border-gray-500"
                    )}
                  >
                    {m}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs uppercase tracking-wider text-gray-500 mb-2 font-bold">Amount (USDT)</label>
              <div className="relative">
                <input 
                  type="number"
                  placeholder={`Min $${currentLimits.min}`}
                  value={wdAmount}
                  onChange={(e) => setWdAmount(e.target.value)}
                  className="w-full bg-gray-900 border border-gray-700 rounded-xl p-4 pl-10 text-lg font-bold text-white focus:outline-none focus:border-blue-500 placeholder:text-gray-600"
                />
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 font-bold">$</span>
              </div>
            </div>

            <div>
              <label className="block text-xs uppercase tracking-wider text-gray-500 mb-2 font-bold">Account Details ({wdMethod})</label>
              <input 
                type="text"
                placeholder={wdMethod === 'Binance UID' ? 'Enter Binance UID' : 'Enter Phone Number'}
                value={wdDetails}
                onChange={(e) => setWdDetails(e.target.value)}
                className="w-full bg-gray-900 border border-gray-700 rounded-xl p-4 text-sm text-white focus:outline-none focus:border-blue-500 placeholder:text-gray-600 font-mono"
              />
            </div>

            <button 
              onClick={handleWithdraw}
              className="w-full py-4 mt-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 rounded-xl font-bold shadow-lg shadow-blue-900/50 flex justify-center items-center gap-2 group"
            >
              Withdraw Now <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function VIPCard({ tier, price, features, isPremium = false, onBuy, active }: { tier: string, price: number, features: string[], isPremium?: boolean, onBuy: () => void, active: boolean }) {
  return (
    <div className={cn(
      "border p-6 rounded-3xl relative overflow-hidden",
      isPremium ? "bg-gradient-to-br from-amber-900/40 to-orange-900/20 border-amber-500/30" : "bg-gray-800 border-gray-700"
    )}>
      {isPremium && (
         <div className="absolute top-0 right-0 bg-amber-500 text-black text-[10px] font-black uppercase px-4 py-1.5 rounded-bl-xl tracking-widest shadow-md">Popular</div>
      )}
      
      <div className="mb-4">
        <h3 className={cn("text-2xl font-black mb-1", isPremium ? "text-amber-400" : "text-white")}>{tier}</h3>
        <p className="text-gray-400 text-sm">30 Days Duration</p>
      </div>

      <ul className="space-y-2 mb-6">
        {features.map((f, i) => (
          <li key={i} className="flex items-center gap-2 text-sm text-gray-300">
             <ShieldCheck size={16} className={isPremium ? "text-amber-400" : "text-blue-400"} />
             {f}
          </li>
        ))}
      </ul>
      
      <button 
        onClick={onBuy}
        disabled={active}
        className={cn(
          "w-full py-3.5 rounded-xl font-bold flex items-center justify-center gap-2 transition-all",
          active ? "bg-gray-900 text-gray-500 border border-gray-800 cursor-not-allowed" :
          isPremium ? "bg-amber-500 hover:bg-amber-400 text-amber-950 shadow-[0_0_20px_rgba(245,158,11,0.3)]" : "bg-white hover:bg-gray-200 text-black"
        )}
      >
        {active ? 'Current Tier' : (
          <>
            Buy with {price} <Star fill="currentColor" size={16} className={active ? "" : isPremium ? "text-amber-900" : "text-amber-500"}/> Stars
          </>
        )}
      </button>
    </div>
  );
}
