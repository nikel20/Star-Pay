import { useState } from 'react';
import { LayoutDashboard, Settings, ListChecks } from 'lucide-react';
import AdminStats from './views/admin/AdminStats';
import AdminSettingsView from './views/admin/AdminSettingsView';
import AdminApprovals from './views/admin/AdminApprovals';
import { cn } from './lib/utils';

type Tab = 'dashboard' | 'settings' | 'approvals';

export default function AdminApp() {
  const [activeTab, setActiveTab] = useState<Tab>('dashboard');

  return (
    <div className="flex flex-col h-[100dvh]">
      <div className="bg-gray-900 border-b border-gray-800 p-4 shrink-0">
        <h1 className="text-xl font-bold bg-gradient-to-r from-red-500 to-orange-500 bg-clip-text text-transparent">
          Admin Dashboard
        </h1>
      </div>
      
      <div className="flex-1 overflow-y-auto pb-20 p-4">
        {activeTab === 'dashboard' && <AdminStats />}
        {activeTab === 'settings' && <AdminSettingsView />}
        {activeTab === 'approvals' && <AdminApprovals />}
      </div>

      <nav className="fixed bottom-0 w-full max-w-lg bg-gray-900 border-t border-gray-800 flex justify-around p-2 pb-safe shrink-0">
        <NavItem 
          icon={<LayoutDashboard size={24} />} 
          label="Stats" 
          active={activeTab === 'dashboard'} 
          onClick={() => setActiveTab('dashboard')} 
        />
        <NavItem 
          icon={<Settings size={24} />} 
          label="Settings" 
          active={activeTab === 'settings'} 
          onClick={() => setActiveTab('settings')} 
        />
        <NavItem 
          icon={<ListChecks size={24} />} 
          label="W/D" 
          active={activeTab === 'approvals'} 
          onClick={() => setActiveTab('approvals')} 
        />
      </nav>
    </div>
  );
}

function NavItem({ icon, label, active, onClick }: { icon: React.ReactNode, label: string, active: boolean, onClick: () => void }) {
  return (
    <button 
      onClick={onClick}
      className={cn(
        "flex flex-col items-center p-2 rounded-xl transition-all",
        active ? "text-red-500" : "text-gray-500 hover:text-gray-300"
      )}
    >
      {icon}
      <span className="text-xs mt-1 font-medium">{label}</span>
    </button>
  );
}
